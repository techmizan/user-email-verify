jQuery(document).ready(function($) {
    var modal = document.getElementById('verification-modal');
    var btn = document.getElementById('verify-btn');
    var span = document.getElementsByClassName('close')[0];
    
	
    var userVerified = document.getElementById('verification-status').value;
    var userID = document.getElementById('user-id').value;

	// Send OTP function
	$(document).ready(function() {
		var session_time = document.getElementById("session-time").value;
		var btn = document.getElementById("resend-otp-btn");
		var sessionTimeout = 60;
		var sessionVerifyOTP = session_time;
		var currentTime = Math.floor(Date.now() / 1000);
		
		if (sessionVerifyOTP && currentTime - sessionVerifyOTP < sessionTimeout) {
			// Session is active, calculate remaining time
			var remainingTime = sessionTimeout - (currentTime - sessionVerifyOTP);
			disableResendButton(btn, remainingTime);
			btn.innerHTML = "Resend";
		} else {
			// Session has expired or not set, enable the button
			enableResendButton(btn);
		}

		btn.addEventListener("click", function() {
			// Set session start time and disable the button
			sessionStorage.setItem("sessionVerifyOTP", currentTime);
			disableResendButton(btn, sessionTimeout);
			
			$.ajax({
				type: 'POST',
				url: ajax_object.ajax_url,
				data: {
					action: 'set_user_otp',
					userID: userID
				},
				success: function(response) {
					//console.log(response);
				},
				error: function(xhr, status, error) {
				}
			});
		});
		
		function disableResendButton(btn, seconds) {
			btn.disabled = true;
			var downloadTimer = setInterval(function() {
				btn.innerHTML = "Resend " + seconds;
				seconds -= 1;

				if (seconds <= 0) {
					clearInterval(downloadTimer);
					enableResendButton(btn);
					sessionStorage.removeItem("sessionVerifyOTP");
				}
			}, 1000);
		}

		function enableResendButton(btn) {
			btn.disabled = false;
			btn.innerHTML = "Send OTP";
		}

	});




// OTP input field input event listener
var verifyBtn = document.getElementById("verify-otp");
var otpInput = document.getElementById('otp-input');
otpInput.addEventListener('input', function() {
    if (otpInput.value.trim() !== '') {
        verifyBtn.disabled = false;
    } else {
        verifyBtn.disabled = true;
    }
});



    // Verify Button click event listener
    verifyBtn.addEventListener("click", function() {
        var otp = otpInput.value;
		var msg = "";
        if (otp.trim() !== '') {
            // Perform the user verification check here using an AJAX request
            $.ajax({
                type: 'POST',
                url: ajax_object.ajax_url,
                data: {
                    action: 'check_user_verification',
                    userID: userID,
                    otp: otp
                },
                success: function(response) {
                    // Handle the response to determine user verification status
                    if (response.success) {
						otpVerifyMsg(msg = response.success);
                        hidePopup();
                    }
					if (response.error) {
						otpVerifyMsg(msg = response.error);
						//console.log(response);
                    }
                }
            });
		//OTP Error message
		function otpVerifyMsg(msg){
			var div = document.getElementById("otp-msg");
			div.style.display	= "block";
			div.innerHTML = msg;
			setTimeout(function() {
				div.style.display	= "none";
			}, 5000); // 5000 milliseconds = 5 seconds
		}
        }
    });




	// Disable all buttons and click events
    function disableButtons() {
		$('button:not(#resend-otp-btn,#send-otp-btn,#back-btn)').prop('disabled', true);
		$(document).on('click', function(event) {
        if (
            !event.target.matches('#email-clk') &&
            !event.target.matches('#verify-otp') &&
            !event.target.matches('#back-btn')
        ) {
            event.preventDefault();
            event.stopPropagation();
        }
    });
    }
    // Enable all buttons and click events
    function enableButtons() {
        $('button').prop('disabled', false);
        $(document).off('click', false); // Re-enable click events
    }


    function showPopup() {
		$('#overlay').fadeIn();
		$('#email-verification-modal').fadeIn();
		disableButtons();
	}
	function hidePopup() {
		$('#overlay').fadeOut();
		$('#email-verification-modal').fadeOut();
		enableButtons();
	}
	$('#close_btn').on('click', function() {
        hidePopup();
    });

	showPopup();
});