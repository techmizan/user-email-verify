// modal.js

jQuery(document).ready(function($) {
    // ... Your existing code ...

    // AJAX request for Resend Verification Email
    $('.resend-verification').click(function(e) {
        e.preventDefault();
		
        var userID = $(this).data('user-id');

        $.ajax({
            type: 'POST',
            url: admin_object.ajax_url,
            data: {
                action: 'resend_verification_email',
                userID: userID
            },
            success: function(response) {
                console.log(response);
                // Handle success response (e.g., display a message)
            },
            error: function(xhr, status, error) {
                console.log(error);
                // Handle error response
            }
        });
    });

    // AJAX request for Verify User
    $('.verify-user').click(function(e) {
        e.preventDefault();

        var userID = $(this).data('user-id');

        $.ajax({
            type: 'POST',
            url: admin_object.ajax_url,
            data: {
                action: 'verify_user',
                userID: userID
            },
            success: function(response) {
                console.log(response);
                window.location.reload();
            },
            error: function(xhr, status, error) {
                console.log(error);
                // Handle error response
            }
        });
    });

    // AJAX request for Remove Verify User
    $('.remove-verify-user').click(function(e) {
        e.preventDefault();

        var userID = $(this).data('user-id');

        $.ajax({
            type: 'POST',
            url: admin_object.ajax_url,
            data: {
                action: 'remove_verify_user',
                userID: userID
            },
            success: function(response) {
                console.log(response);
                window.location.reload();
            },
            error: function(xhr, status, error) {
                console.log(error);
                // Handle error response
            }
        });
    });

});
