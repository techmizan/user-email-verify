<?php
    global $wpdb;
    $user_id = "";
    $table_name = $wpdb->prefix . 'tgm_email_verification';
    $query = $wpdb->prepare("SELECT verified FROM $table_name WHERE user_id = %d", $user_id);
    $verification_status = $wpdb->get_var($query);
	
	$user = wp_get_current_user();
	$user_id = $user->ID;
	$user_email = $user->user_email;
	$user_meta = get_user_meta( $user_id, "tgm_user_verification",true);
	if($user_meta){
	    $top_time = $user_meta['session_time'];
	}
?>


<div id="overlay" class="overlay" style="display:none"></div>

<div id="email-verification-modal" class="modal" style="display:none">
    <article id="modal-content" class="modal-container">
        <header class="modal-container-header">
			<h4 class="modal-container-title">Verification Required</h4>
		</header>
		<section class="modal-container-body rtf">
		<p style="font-size: 13px">
			Apologies, but you won't be able to initiate any orders or full access controls until the verification process is successfully completed.
		</p>
        <p>
			We sent verification code to <?=$user_email?>. To verify your email address, please check your inbox or spam folder and enter the code below.
		</p>
		<form>
		<input type="hidden" id="user-id" value="<?=$user_id?>">
		<input type="hidden" id="session-time" value="<?=$top_time?>">
		<input type="hidden" id="verification-status" value="<?=$verification_status?>">
        <div class="inline">
			<input type="number" class="otp-input" id="otp-input" placeholder="Enter the otp code" required>
			<button id="resend-otp-btn" class="button-send-otp">Send OTP</button>
		</div>
		</form>
		<div class="error-otp-msg" id="otp-msg"></div>
			<p class="modal-support-msg">
If you encounter any challenges during the process of verifying your account, please don't hesitate to reach out to our support team for assistance.
<br>Email: <a id="email-clk" href="mailto:support@thegamersmall.com">support@thegamersmall.com</a>
</p>
		</section>
		<footer class="modal-container-footer">
			<a href="<?=home_url()?>"><button id="back-btn" class="button is-home">Home</button></a>
			<button id="verify-otp" class="button is-primary">Verify</button>
		</footer>
		
    </article>
</div>