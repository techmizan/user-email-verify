<?php

class TGM_Email_Verification {

	public function __construct() {
		$this->init_function();
        register_activation_hook(__FILE__, array($this, 'create_table'));
        register_deactivation_hook(__FILE__, array($this, 'drop_table_table'));

	}




    public function init_function(){
        add_filter('woocommerce_locate_template', array($this,'custom_woocommerce_login_form_template'), 1, 3);
        
		//display modal
		add_action( 'wp', array($this,'display_modal' ));
        add_action( 'wp_enqueue_scripts', array($this,'enqueue_modal_scripts')); 
        add_action('admin_enqueue_scripts', array($this,'enqueue_email_verify_script'));


		//admin script
		add_filter('manage_users_columns', array($this,'add_verification_status_column'));
		add_action('manage_users_custom_column', array($this,'verification_action_column'), 10, 3);
		add_action('manage_users_custom_column', array($this,'display_verification_status_column'), 10, 3);
		add_action('wp_ajax_resend_verification_email', array($this,'resend_verification_email_callback'));
		add_action('wp_ajax_verify_user', array($this,'verify_user_callback'));
		add_action('wp_ajax_remove_verify_user', array($this,'remove_verify_user_callback'));

		//modal script
        add_action('wp_ajax_set_user_otp', array($this,'set_user_otp'));
		add_action('wp_ajax_nopriv_set_user_otp', array($this,'set_user_otp'));
		add_action('wp_ajax_check_user_verification', array($this,'check_user_verification_callback'));
		add_action('wp_ajax_nopriv_check_user_verification', array($this,'check_user_verification_callback'));

    }
    
    public function enqueue_email_verify_script($hook){
		if($hook === 'users.php'){
			wp_enqueue_script('user-actions-script', plugin_dir_url(__DIR__) . 'assets/js/admin-script.js', array('jquery'), '1.0', true);

			// Localize script with the AJAX URL
			wp_localize_script('user-actions-script', 'admin_object', array(
				'ajax_url' => admin_url('admin-ajax.php'),
			));
		}
	}
    public function enqueue_modal_scripts() {
        wp_register_style( 'modal-styles', plugin_dir_url(__DIR__). 'assets/css/styles.css');
        wp_register_script( 'modal-script', plugin_dir_url(__DIR__). 'assets/js/modal.js', array('jquery'), '1.0', true );
		wp_localize_script('modal-script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
    }
 

    
    public function display_modal($page_id) {
		global $wpdb;
		$cart_page_id = wc_get_page_id('cart');
		$checkout_page_id = wc_get_page_id('checkout');
		$my_account_page_id = wc_get_page_id('myaccount');
		$current_page = get_the_ID();
		$user = wp_get_current_user();
		$user_id = $user->ID;

		$status = $this->is_user_verified($user_id);

		if( !is_user_logged_in() ){
			return;
		}
		elseif(!empty($status)){
			return;
		}
		elseif(($cart_page_id == $current_page || $checkout_page_id == $current_page || $my_account_page_id == $current_page)){
			wp_enqueue_style( 'modal-styles' );
			wp_enqueue_script( 'modal-script' );
			include plugin_dir_path(__DIR__). 'templates/verification-modal.php';
		}else{return;}
    }
	
	//check user is verified or not
	public function is_user_verified($user_id){
		global $wpdb;
		$table_name = $wpdb->prefix . 'tgm_email_verification';
		$is_verified = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d AND verified = 1", $user_id));
		return $is_verified;
	}
	
	//check user data
	public function get_user_data($user_id){
		global $wpdb;
		$table_name = $wpdb->prefix . 'tgm_email_verification';
		$user_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d", $user_id));
		return $user_data;
	}
	
    public function set_user_otp() {
		if(!empty($_POST['GetTime']) && !empty($_POST['userID'])){
			$user_meta = get_user_meta( $_POST['userID'], "tgm_user_verification",true);
			$top_time = $user_meta['time'];
			header('Content-Type: application/json');
			echo json_encode(array('time_meta' => $top_time));
			exit();
		}
		if ($_POST['userID']) {
			global $wpdb;
			$otp = rand(111111,999999);
			$user_id = absint($_POST['userID']);
			$time = time();
			// Check if the user's record exists
			$response = array();
			
			$meta_key = "tgm_user_verification";
			$new_array = array(
				'user_otp' => $otp,
				'session_time'=>$time
			);
			
			
			if($existing_array = get_user_meta($user_id, $meta_key, true)){
				if((update_user_meta($user_id, $meta_key, $new_array))===false){
					$response['DataUpdate'] = false;
				}else{
					$response['DataUpdate'] = true;
				}
			}else{
				if((add_user_meta($user_id,$meta_key,$new_array))===false){
					$response['DataInsert'] = false;
				}else{
					$response['DataInsert'] = true;
					}
			}
			//Sending email
			$this->send_email($user_id,$otp);


			wp_send_json($response);
		}
	}
    
	public function send_email($user_id,$otp){
		$meta_value = get_user_meta($user_id, "tgm_user_verification", true);
		$user_otp = $meta_value['otp_code'];
		$user = get_userdata($user_id);
		$user_email = $user->user_email;
		$subject = 'Your OTP Verification Code';
		$template_path = plugin_dir_path(__DIR__) . 'templates/email-template.php';
		$message = file_get_contents($template_path);
		$placeholders = array(
			'[email_title]' => "The Gamers Mall",
			'[user_id]' => $user_id,
			'[user_otp]' => $otp,
		);
	    $message = strtr($message, $placeholders);
		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: The Gamers Mall <no-reply@thegamersmall.com>',
		);
	    $email_sent = wp_mail($user_email, $subject, $message, $headers);

	}

	//Modal User verification action
    public function check_user_verification_callback() {
     $response = array();

    if (isset($_POST['userID'], $_POST['otp'])) {
        $user_id = intval($_POST['userID']);
        $otp = sanitize_text_field($_POST['otp']);

		$user_meta = get_user_meta($user_id, "tgm_user_verification", true);
		if($user_meta){
			$otp_data = $user_meta['user_otp'];
			$session_time = $user_meta['session_time'];
			$timeout = 300;
			$current_time = time();
			if($otp_data==$otp){
				if($current_time-$session_time>$timeout){
					$response['error'] = "Sorry OTP was expired";
				}else{
					if($this->set_user_verified($user_id)){
					$response['success'] = "Successfully Verified";
					}else{$response['error'] = "User not verified";}
				}
				
			}else{$response['error'] = "Sorry otp not matched";}
		}else{$response['error'] = "Data not found!";}
    } else {
        $response['error'] = "Something wrong, please again!";
    }

    wp_send_json($response);

    }

	//set user verified
	public function set_user_verified($user_id){
        global $wpdb;
        $table_name = $wpdb->prefix . 'tgm_email_verification';
		$data = array(
				'user_id' => $user_id,
				'verified' => "1"
		);
		if($this->get_user_data($user_id)){
			$result = $wpdb->update($table_name, $data, array('user_id' => $user_id));
		}else{
			$result = $wpdb->insert($table_name, $data);
		}
		
		if(!empty($result)){
			$meta_key = 'tgm_user_verification';
			$meta_value = array(
			'verified'=> 1
			);
			update_user_meta($user_id, $meta_key,$meta_value);
		}
		return $result;
	}
	
	//remove user verified
	public function remove_user_verified($user_id){
        global $wpdb;
        $table_name = $wpdb->prefix . 'tgm_email_verification';
		$data_to_update = array(
				'verification_code' => "",
				'verified' => 0
		);
		$update_result = $wpdb->update($table_name, $data_to_update, array('user_id' => $user_id));
		return $update_result;
	}
    
	public function custom_woocommerce_login_form_template($template, $template_name, $template_path) {
        if ($template_name === 'myaccount/form-login.php') {
            $template = PLUGIN_DIR.'templates/form-login.php';
        }
        if ($template_name === 'checkout/form-login.php') {
            $template = PLUGIN_DIR.'templates/checkout-login.php';
        }
        return $template;
	}
    
	public function add_custom_user_actions($actions, $user) {
		if ($user instanceof WP_User && $user->ID) {
			$actions['resend_verification'] = '<a href="#" data-user-id="' . esc_attr($user->ID) . '" class="resend-verification">Resend Verification Email</a>';
			$actions['verify'] = '<a href="#" data-user-id="' . esc_attr($user->ID) . '" class="verify-user">Verify</a>';
		}
		return $actions;
	}
    
	public function add_verification_status_column($columns) {
		$columns['verification_actions'] = 'Action';
		$columns['verification_status'] = 'Verification Status';
		return $columns;
	}
    
    public function display_verification_status_column($value, $column_name, $user_id) {
		if ($column_name === 'verification_status') {
			$res = $this->is_user_verified($user_id);
			if (isset($res)) {
				return '<span style="color: green;">Verified</span>';
			} else {
				return '<span style="color: red;">Not Verified</span>';
			}
		}
		return $value;
	}

	public function verification_action_column($value, $column_name, $user_id) {
		if ($column_name === 'verification_actions') {
			return '
			<a href="#" data-user-id="' . $user_id . '" class="resend-verification">Resend Email</a>
			<br>
			<a href="#" data-user-id="' . $user_id . '" class="remove-verify-user">Remove Verify</a>
			<br>
			<a href="#" data-user-id="' . $user_id . '" class="verify-user">Verify</a>';
		}
		return $value;
	}

	public function resend_verification_email_callback() {
		if (isset($_POST['userID'])) {
			$response = array();
			$user_id = intval($_POST['userID']);

			$response = $this->set_user_otp($user_id);

			$response['success'] = true;
		} else {
			$response['success'] = false;
		}

		wp_send_json($response);
	}
	
	//Admin user verify
	public function verify_user_callback() {
		$response = array();
		if (isset($_POST['userID'])) {
			$response = array();
			$user_id = intval($_POST['userID']);

			if(!empty($this->set_user_verified($user_id))){
				$response['success'] = "Successfully verified user ".$_POST['userID'];
			}else{$response['fasle'] = "Not verified user ".$_POST['userID'];}
		} else {
			$response['success'] = false;
		}

		wp_send_json($response);
	}
	public function remove_verify_user_callback() {
		$response = array();
		if (isset($_POST['userID'])) {
			$response = array();
			$user_id = intval($_POST['userID']);

			if(!empty($this->remove_user_verified($user_id))){
				$response['success'] = "User unverified";
				$meta_key = 'tgm_user_verification';
				$meta_value = array(
					'verified'=> 0
				);
				update_user_meta($user_id, $meta_key,$meta_value);
			}else{$response['false'] = "Data not inserted user ".$_POST['userID'];}
		} else {
			$response['success'] = false;
		}

		wp_send_json($response);
	}


	//Create table
    public function create_table(){
        global $wpdb;
        $table_name = $wpdb->prefix . 'tgm_email_verification';
        $sql = "
            CREATE TABLE IF NOT EXISTS $table_name (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                verification_code VARCHAR(10) NOT NULL,
                verified TINYINT(1) DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";
        $charset_collate;
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    }
	//Drop table
    public function drop_table_table(){
        global $wpdb;

        $table_name = $wpdb->prefix . 'tgm_email_verification';

        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name) {
            $wpdb->query("DROP TABLE IF EXISTS $table_name");
        }
    }
}

?>